package curtin.edu.au.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

//This activity contains the title screen with the settings option and map button.
public class MainActivity extends AppCompatActivity {

    private Button map, settings;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        map = findViewById(R.id.map);
        settings = findViewById(R.id.settings);

        //Starts the map activity
        map.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, mapActivity.class);
                        startActivity(intent);

                    }

                }
        );

        //Starts the settings activity
        settings.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this, settingsActivity.class);
                        startActivity(intent);

                    }

                }
        );




    }
}
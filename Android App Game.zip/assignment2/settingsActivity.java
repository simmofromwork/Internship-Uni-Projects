package curtin.edu.au.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//Just handles extracting the input data and saving it to the settings
public class settingsActivity extends AppCompatActivity {
    private Button back;
    private EditText setWidth, setHeight, setMoney;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        setWidth = findViewById(R.id.setWidth);
        setHeight = findViewById(R.id.setHeight);
        setMoney = findViewById(R.id.setMoney);
        back = findViewById(R.id.back);




        //When back is pressed the input data, provided it is not an empty string, is saved into the game settings
        back.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if(!(setWidth.getText().toString().equals(""))){
                            Settings.getInstance().setWidth(Integer.parseInt(setWidth.getText().toString()));
                            //GameData.getInstance().updateMap();
                        }
                        if(!(setHeight.getText().toString().equals(""))){
                            Settings.getInstance().setHeight(Integer.parseInt(setHeight.getText().toString()));
                            //GameData.getInstance().updateMap();
                        }
                        if(!(setMoney.getText().toString().equals(""))){
                            GameData.getInstance().setMoney(Integer.parseInt(setMoney.getText().toString()));
                        }
                        finish();
                    }

                }
        );

    }
}
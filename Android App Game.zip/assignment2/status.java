package curtin.edu.au.assignment2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DecimalFormat;

//This fragment displays the day, the money and the recent income for the city
public class status extends Fragment {

    private TextView profit, time, money;
    private int gainz = 0;
    public status(int inProfit){
        gainz = inProfit;
    }

    public status() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_status, container, false);



        profit = (TextView)view.findViewById(R.id.profit);
        time = (TextView)view.findViewById(R.id.time);
        money = (TextView)view.findViewById(R.id.money);




        time.setText("         Day: " +Integer.toString(GameData.getInstance().getGameTime()));
        money.setText("    Money: $" + Integer.toString(GameData.getInstance().getMoney()));
        profit.setText("  Income: $" + Integer.toString(gainz));


        return view;
    }


}
package curtin.edu.au.assignment2;

import java.util.Set;

public class Residential extends Structure{
        private int cost;

        public Residential(){
            super();
            cost = Settings.getInstance().getHouseBuildingCost();
        }


        public int getCost(){
            return cost;
        }
}

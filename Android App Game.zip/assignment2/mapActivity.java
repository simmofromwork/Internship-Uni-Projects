package curtin.edu.au.assignment2;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;

import android.view.View;

//This activity simply pieces together the different fragments that make the map screen.
public class mapActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);




        FragmentManager fm = getSupportFragmentManager();
        //Selector is the bottom recyclerview panel for selecting structures.
        selectorRecycler selector = (selectorRecycler)fm.findFragmentById(R.id.selector);
        if(selector == null){
            selector = new selectorRecycler();
            fm.beginTransaction().add(R.id.selector, selector).commit();
        }
        //Map is the map gird in the centre.
        mapRecycler map = (mapRecycler)fm.findFragmentById(R.id.mapGrid);
        if(map == null) {
            map = new mapRecycler();
            fm.beginTransaction().add(R.id.mapGrid, map).commit();
        }

        //Tools is the top panel that contains the back button, the time button and the details button
        topTools top = (topTools)fm.findFragmentById(R.id.tools);
        if(top == null) {
            top = new topTools();
            fm.beginTransaction().add(R.id.tools, top).commit();
        }
        //The stats panel contains half of the stats that sit below the tools.
        status stats = (status)fm.findFragmentById(R.id.stats);
        if(stats == null) {
            stats = new status();
            fm.beginTransaction().add(R.id.stats, stats).commit();
        }

        //stats2 contains the other half of the stats like employmentrate.
        stats2 stats2 = (stats2)fm.findFragmentById(R.id.stats2);
        if(stats2 == null) {
            stats2 = new stats2();
            fm.beginTransaction().add(R.id.stats2, stats2).commit();
        }

    }
}
package curtin.edu.au.assignment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import static android.app.Activity.RESULT_CANCELED;


//https://www.youtube.com/watch?v=ondCeqlAwEI

public class camera extends Fragment {
    //Private files for image view and row and column
    private ImageView camView;
    private int row, col;
    //Alternate constructor that gest the row and column for setting the bitmap
    public camera(int inRow, int inCol){
        row = inRow;
        col = inCol;
    }

    public camera() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_camera, container, false);

        camView = (ImageView)view.findViewById(R.id.camView);
        //Call camera
        camView.setImageBitmap(GameData.getInstance().getMap()[row][col].getImage());
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        startActivityForResult(intent, 0);


        return view;
    }
    //Get camera result and set the map elements bitmap image for changing the map structure
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode != RESULT_CANCELED) {
            if (data != null) {
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                //sthis doesnt really matter, just displays the image briefly
                camView.setImageBitmap(bitmap);
                //Sets the mapelemnt bitmap image
                GameData.getInstance().getMap()[row][col].setBitmap(bitmap);
            }
        }

    }
}
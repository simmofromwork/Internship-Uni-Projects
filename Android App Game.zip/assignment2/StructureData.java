package curtin.edu.au.assignment2;


//This classes has each structure type stored in the correct array and allows for checking structure types
public class StructureData {
    private static StructureData structureData;
    private Residential[] residentials;
    private Commercial[] commercials;
    private Road[] roads;

    private StructureData() {
        //Work out the size of these arrays

        residentials = new Residential[4];
        commercials = new Commercial[4];
        roads = new Road[15];
        initialiseArrays();
    }

    private void initialiseArrays(){
        int ii;
        for(ii=0; ii<15; ii++){
            roads[ii] = new Road();
        }
        for(ii=0; ii<4; ii++){
            residentials[ii] = new Residential();
        }
        for(ii=0; ii<4; ii++){
            commercials[ii] = new Commercial();
        }


        residentials[0].setImageId(R.drawable.ic_building1);
        residentials[1].setImageId(R.drawable.ic_building2);
        residentials[2].setImageId(R.drawable.ic_building3);
        residentials[3].setImageId(R.drawable.ic_building4);
        commercials[0].setImageId(R.drawable.ic_building5);
        commercials[1].setImageId(R.drawable.ic_building6);
        commercials[2].setImageId(R.drawable.ic_building7);
        commercials[3].setImageId(R.drawable.ic_building8);
        roads[0].setImageId(R.drawable.ic_road_e);
        roads[1].setImageId(R.drawable.ic_road_ew);
        roads[2].setImageId(R.drawable.ic_road_n);
        roads[3].setImageId(R.drawable.ic_road_ne);
        roads[4].setImageId(R.drawable.ic_road_new);
        roads[5].setImageId(R.drawable.ic_road_ns);
        roads[6].setImageId(R.drawable.ic_road_nse);
        roads[7].setImageId(R.drawable.ic_road_nsew);
        roads[8].setImageId(R.drawable.ic_road_nsw);
        roads[9].setImageId(R.drawable.ic_road_nw);
        roads[10].setImageId(R.drawable.ic_road_s);
        roads[11].setImageId(R.drawable.ic_road_se);
        roads[12].setImageId(R.drawable.ic_road_sew);
        roads[13].setImageId(R.drawable.ic_road_sw);
        roads[14].setImageId(R.drawable.ic_road_w);

    }

    public static StructureData getInstance(){
        if(structureData == null){
            structureData = new StructureData();
        }
        return structureData;
    }

    //Checks what structure type it is and returns the according cost
    public int getCost(int inDrawable){
        int cost = 0;
        if(isRoad(inDrawable)){
            cost = GameData.getInstance().getSettings().getRoadBuildingCost();
        }
        else if(isCommercial(inDrawable)){
            cost = GameData.getInstance().getSettings().getCommBuildingCost();
        }
        else if(isResidential(inDrawable)){
            cost = GameData.getInstance().getSettings().getHouseBuildingCost();
        }
        return cost;

    }

    //Checks if the input structure is in the road array.
    public boolean isRoad(int inDrawable){
        int ii;
        boolean isRoad = false;
        for(ii=0; ii < roads.length; ii++){
            if(roads[ii].getImageId() == inDrawable){
                isRoad = true;
            }
        }
        return isRoad;
    }
    //Checks if the input structure is in the commercial array
    public boolean isCommercial(int inDrawable){
        int ii;
        boolean isComm = false;
        for(ii=0; ii < commercials.length; ii++){
            if(commercials[ii].getImageId() == inDrawable){
                isComm = true;
            }
        }
        return isComm;
    }
//Checks if the input structure is in the residential array
    public boolean isResidential(int inDrawable){
        int ii;
        boolean isRes = false;
        for(ii=0; ii < residentials.length; ii++){
            if(residentials[ii].getImageId() == inDrawable){
                isRes = true;
            }
        }
        return isRes;
    }


}

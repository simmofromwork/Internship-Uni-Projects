package curtin.edu.au.assignment2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ImageView;


public class mapRecycler extends Fragment {

    //This fakeArray is uses to operate the recyclerview. It is the size of the product of the maps dimensions
    MapElement fakeArray[] = new MapElement[Settings.getInstance().getHeight()*Settings.getInstance().getWidth()];

//Various private variable declarations
    private int mapPos;
    private static mapRecycler instance = null;
    private boolean details = false;
    private MyAdapter adapter = new MyAdapter(fakeArray);

    //Allows the fragment to be accessed remotely
    public static mapRecycler getInstance(){
        return instance;
    }

    //The current clicked position can be accessed by other fragments
    public int getMapPos(){
        return mapPos;
    }

    //Allows the program to know if details has been clicked or not.
    public void setDetails(boolean inState){
        if(mapRecycler.getInstance() != null) {
            details = inState;
        }
    }


    public mapRecycler() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.recycler, container, false);

        RecyclerView rv = (RecyclerView) view.findViewById(R.id.recycler);
        // Specify how it should be laid out using gridlayout

        rv.setLayoutManager(new GridLayoutManager(getActivity(), GameData.getInstance().getHeight(), GridLayoutManager.HORIZONTAL, false));


        // Hook it up
        rv.setAdapter(adapter);

        instance = this;

        // Inflate the layout for this fragment
        return view;
    }

    //This method allows the adapter to be updated after the thumbnails are added to mapElements
    @Override
    public void onResume() {
        super.onResume();
        adapter.notifyDataSetChanged();
    }

    //Adapter class and holder class

    private class MyAdapter extends RecyclerView.Adapter<MyDataVHolder>
    {
        private MapElement[] data;
        private int position;
        public MyAdapter(MapElement[] data)
        {
            this.data = data;
        }
        @Override
        public int getItemCount()
        {
            return data.length;
        }

        @Override
        public MyDataVHolder onCreateViewHolder(ViewGroup parent,
                                                int viewType)
        {
            LayoutInflater li = LayoutInflater.from(getActivity()); // <-- Fragment method
            return new MyDataVHolder(li, parent);
        }

        @Override
        public void onBindViewHolder(MyDataVHolder vh, int index)
        {
            //Converts the single array index to the 2d array index.
            position = index;
            int row = position % GameData.getInstance().getHeight();
            int col = position / GameData.getInstance().getHeight();
            vh.bind(GameData.getInstance().getMap()[row][col], index);


        }

    }

    private class MyDataVHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        public MyDataVHolder(LayoutInflater li, ViewGroup parent) {
            super(li.inflate(R.layout.grid_cell,
                    parent, false));
            //Sizes the grid_cells to squares based on height
            int size = parent.getMeasuredHeight() / (GameData.getInstance().getHeight())+1;
            ViewGroup.LayoutParams lp = itemView.getLayoutParams();
            lp.width = size;
            lp.height = size;

            imageView =(ImageView)itemView.findViewById(R.id.imageView);
        }

        public void bind(final MapElement data, final int position) // Called by your adapter
        {

            //Access the current position and get bitmap if its been set.
            int row = position % GameData.getInstance().getHeight();
            int col = position / GameData.getInstance().getHeight();
            Bitmap bit = GameData.getInstance().getMap()[row][col].getImage();

            if(bit!=null){
                imageView.setImageBitmap(bit);

            }
            else {
                imageView.setImageResource(data.getStructure().getImageId());
            }

            imageView.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //set current recyclerview index for getting coordinates for deatils
                            mapPos = position;
                            int selected = selectorRecycler.getInstance().getSelected();
                            //deatils is set from the topTools fragment when the user clicks details
                            if(details){
                                if(!(data.getStructure().getImageId() == R.drawable.ic_launcher_background)) {
                                    Intent intent = new Intent(getActivity(), details.class);
                                    startActivity(intent);
                                }
                            }
                            else{
                                //Gets the row/col index and the selected structure from selectorrecycler
                                MapElement[][] map = GameData.getInstance().getMap();

                                int row = position % GameData.getInstance().getHeight();
                                int col = position / GameData.getInstance().getHeight();
                                //Allows for demolition
                                //Decrements the residential or commercial building count if demolished
                                if(selected == R.drawable.ic_launcher_background){
                                    imageView.setImageResource(selected);
                                    if(StructureData.getInstance().isResidential(map[row][col].getStructure().getImageId())){
                                        GameData.getInstance().decRes();
                                    }
                                    else if(StructureData.getInstance().isCommercial(map[row][col].getStructure().getImageId())){
                                        GameData.getInstance().decComm();
                                    }
                                    //Since we have demolishes the element we need to reset the name and bitmap
                                    map[row][col].setOwnerName("set Name Below");
                                    map[row][col].setBitmap(null);
                                    //Also update the fragments with stats like population etc
                                    FragmentManager fm = getParentFragmentManager();
                                    fm.beginTransaction().replace(R.id.stats, new status()).commit();
                                    fm.beginTransaction().replace(R.id.stats2, new stats2()).commit();
                                    //Finally set tje new structure accordingly
                                    map[row][col].getStructure().setImageId(selected);
                                }
                                //Only allows building on grass square and Only if adjacent to a road.
                                else if(map[row][col].getStructure().getImageId() == R.drawable.ic_launcher_background) {
                                    if (StructureData.getInstance().isRoad(selected)) {
                                        //If is a road, build without question
                                        build(imageView, row, col, selected);
                                    } else if (isAdajacent(row, col)) {
                                        //if is not a road or piece of grass and is adjacent, build
                                        build(imageView, row, col, selected);
                                        if (StructureData.getInstance().isResidential(selected)) {
                                            //If residential then incrememnt the number of residentials
                                            GameData.getInstance().incRes();
                                        } else {
                                            //Increment for commercials
                                            GameData.getInstance().incComm();
                                        }
                                    }
                                }

                            }

                        }
                    }
            );
        }


    }

    //Works out if the input coordinates arew adjacent to a road.
    public boolean isAdajacent(int inRow, int inCol){
        boolean adjacent = false;
        StructureData sd = StructureData.getInstance();
        GameData gd = GameData.getInstance();
        //First if statement checks if the coords will cause an index out of bounds exception
        if(inRow-1 >= 0) {
            //Second if checks if the image id of the coordinate 1 unit up is a road.
            if (sd.isRoad(gd.getMap()[inRow - 1][inCol].getStructure().getImageId())) {
                adjacent = true;
            }
        }
        if(inRow+1 < gd.getHeight()) {
            if(sd.isRoad(gd.getMap()[inRow + 1][inCol].getStructure().getImageId())) {
                adjacent = true;
            }
        }
        if(inCol-1 >= 0) {
            if (sd.isRoad(gd.getMap()[inRow][inCol - 1].getStructure().getImageId())) {
                adjacent = true;
            }
        }
        if(inCol +1 <gd.getWidth()) {
            if (sd.isRoad(gd.getMap()[inRow][inCol + 1].getStructure().getImageId())) {
                adjacent = true;
            }
        }
        return adjacent;

    }


    //build() sets the imageview, sets the map position and sets the new money amount
    public void build(ImageView imageView, int row, int col, int selected){
        if(GameData.getInstance().getMoney() >= StructureData.getInstance().getCost(selected)){
            imageView.setImageResource(selected);
            GameData.getInstance().getMap()[row][col].getStructure().setImageId(selected);
            //Set money to current amount subtract the cost of the selected item
            GameData.getInstance().setMoney(GameData.getInstance().getMoney() - StructureData.getInstance().getCost(selected));
            FragmentManager fm = getParentFragmentManager();
            fm.beginTransaction().replace(R.id.stats, new status()).commit();
            fm.beginTransaction().replace(R.id.stats2, new stats2()).commit();
        }

    }


}
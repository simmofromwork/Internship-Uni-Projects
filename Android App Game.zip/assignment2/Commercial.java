package curtin.edu.au.assignment2;

public class Commercial extends Structure{

    private int cost;

    public Commercial(){
        super();
        cost = Settings.getInstance().getCommBuildingCost();
    }


    public int getCost(){
        return cost;
    }


}

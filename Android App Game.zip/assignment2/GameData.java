package curtin.edu.au.assignment2;

//is a singleton and contains all of the crucial data for each map element and other variables or fixed values.
public class GameData {

    private static GameData gameData;
    private Settings settings;
    private MapElement map[][];
    private int money;
    private int height;
    private int width;
    private int gameTime;
    private int nRes;
    private int nComm;

    private GameData(){
        settings = Settings.getInstance();
        height = settings.getHeight();
        width = settings.getWidth();
        map = new MapElement[height][width];
        map = initialiseMap(map);
        money = settings.getMoney();
        gameTime = 0;
        nRes = 0;
        nComm = 0;
    }

    //Initialises each element of the 2d array
    private MapElement[][] initialiseMap(MapElement[][] inMap){
        int ii, jj;
        for(ii=0; ii< height; ii++){
            for(jj=0; jj<width; jj++){
                inMap[ii][jj] = new MapElement();
            }
        }
        return inMap;
    }

    public static GameData getInstance(){
        if(gameData == null){
            gameData = new GameData();
        }
        return gameData;
    }

    public Settings getSettings(){
        return settings;
    }

    public MapElement[][] getMap(){
        return map;
    }

    public int getHeight(){
        return height;
    }

    public int getWidth(){
        return width;
    }

    public int getMoney(){
        return money;
    }

    public void setMoney(int inMoney){
        money = inMoney;
    }

    public int getGameTime(){
        return gameTime;
    }

    //Time step advances the game time and returns the income for the current day.
    public int timeStep(){
        gameTime++;
        int temp;
        temp = money;
        money = settings.timeStep(money);
        return money - temp;
    }

    public void incRes(){
        nRes++;
    }

    public void incComm(){
        nComm++;
    }

    public void decRes(){
        nRes--;
    }

    public void decComm(){
        nComm--;
    }

    public int getnRes(){
        return nRes;
    }

    public int getnComm(){
        return nComm;
    }


}

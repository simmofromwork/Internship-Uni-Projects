package curtin.edu.au.assignment2;

public class Structure {
    private int imageId;
    private int cost;

    public Structure(){
        imageId = R.drawable.ic_launcher_background;
        cost = 0;
    }

    public void setImageId(int inImageID){
        imageId = inImageID;
    }


    public int getImageId(){
        return imageId;
    }




}

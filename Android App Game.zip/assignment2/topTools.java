package curtin.edu.au.assignment2;

import android.app.DownloadManager;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

//Video on how to use openweather api to get temperature.
//https://www.youtube.com/watch?v=8-7Ip6xum6E

//This fragment displays the back, time, and details button as well as the weather for perth which is periodically updated every 50 timesteps of when the activity is return to from another activity.
public class topTools extends Fragment {

    private Button back, timeStep, details;
    private TextView temperature;



    public topTools() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view  = inflater.inflate(R.layout.fragment_top_tools, container, false);
        back = (Button)view.findViewById(R.id.back);
        timeStep = (Button)view.findViewById(R.id.timeStep);
        details = (Button)view.findViewById(R.id.details);
        temperature = (TextView)view.findViewById(R.id.temperature);
        //Finds temp when the map activity starts and updates every 50 units of time
        findTemp();





        back.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        getActivity().finish();


                    }
                }
        );


        timeStep.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                            //Profit found for each timestep and updates fragment
                            int profit = GameData.getInstance().timeStep();
                            //Update the stats panel every timestep to show change in income/money/time
                            FragmentManager fm = getParentFragmentManager();
                            fm.beginTransaction().replace(R.id.stats, new status(profit)).commit();
                            fm.beginTransaction().replace(R.id.stats2, new stats2()).commit();
                            //Every 50 time steps the temperature is updated
                            if(GameData.getInstance().getGameTime()%50 ==0){
                                findTemp();
                            }
                    }
                }
        );


        details.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        mapRecycler.getInstance().setDetails(true);

                    }
                }
        );



        return view;
    }
//Parse the JSON array and extract the temperature
    public void findTemp(){
        String url = "http://api.openweathermap.org/data/2.5/weather?q=perth,australia&appid=ea1059ecab1456ca323e636bb94ce33a&units=Metric";

        JsonObjectRequest jor = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>(){
            @Override
            public void onResponse(JSONObject response){
                try {
                    JSONObject main_object = response.getJSONObject("main");
                    JSONArray array = response.getJSONArray("weather");
                    double temp = main_object.getDouble("temp");
                    DecimalFormat df = new DecimalFormat("####0.0");

                    temperature.setText(" Perth " +df.format(temp) + " \u2103");


                }catch(JSONException e){
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                System.out.println(error);
            }
        }
        );


        RequestQueue queue = Volley.newRequestQueue(getActivity());
        queue.add(jor);


    }





}
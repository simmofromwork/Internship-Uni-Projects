package curtin.edu.au.assignment2;

import android.graphics.Bitmap;

public class MapElement {
    private Structure structure;
    private Bitmap image;
    private String ownerName;

    public MapElement(){
        structure = new Structure();
        image = null;
        ownerName = "set Name Below";
    }

    public Bitmap getImage(){

        return image;
    }

    public void setBitmap(Bitmap inImage){
        image = inImage;
    }

    public Structure getStructure(){
        return structure;
    }

    public String getOwnerName(){
        return ownerName;
    }

    public void setOwnerName(String inName){
        ownerName = inName;
    }

}

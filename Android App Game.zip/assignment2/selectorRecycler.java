package curtin.edu.au.assignment2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class selectorRecycler extends Fragment {


    private int selected;
    private static selectorRecycler instance = null;

    public static selectorRecycler getInstance(){
        return instance;
    }

    public int getSelected(){
        return selected;
    }
    //Contains all structures in int array
    private int structures[] = {R.drawable.ic_launcher_background, R.drawable.ic_building1,
            R.drawable.ic_building2, R.drawable.ic_building3, R.drawable.ic_building4,
            R.drawable.ic_building5,R.drawable.ic_building6,R.drawable.ic_building7,
            R.drawable.ic_building8, R.drawable.ic_road_e,R.drawable.ic_road_ew,R.drawable.ic_road_n,
            R.drawable.ic_road_ne,R.drawable.ic_road_new,R.drawable.ic_road_ns,
            R.drawable.ic_road_nse,R.drawable.ic_road_nsew,R.drawable.ic_road_nsw,R.drawable.ic_road_nw,
            R.drawable.ic_road_s,R.drawable.ic_road_se,R.drawable.ic_road_sew,R.drawable.ic_road_sw,
            R.drawable.ic_road_w };
    public selectorRecycler() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.recycler, container, false);

        RecyclerView rv = (RecyclerView) view.findViewById(R.id.recycler);
        // Specify how it should be laid out using gridlayout

        rv.setLayoutManager(new GridLayoutManager(getActivity(), 1, GridLayoutManager.HORIZONTAL, false));

        selectorRecycler.MyAdapter adapter = new selectorRecycler.MyAdapter(structures);
        // Hook it up
        rv.setAdapter(adapter);
        instance = this;

        // Inflate the layout for this fragment
        return view;
    }


    //Adapter class and holder class

    private class MyAdapter extends RecyclerView.Adapter<selectorRecycler.MyDataVHolder>
    {
        private int[] data;
        private int position;
        public MyAdapter(int[] data)
        {
            this.data = data;
        }
        @Override
        public int getItemCount()
        {
            return data.length;
        }

        @Override
        public selectorRecycler.MyDataVHolder onCreateViewHolder(ViewGroup parent,
                                                            int viewType)
        {
            LayoutInflater li = LayoutInflater.from(getActivity()); // <-- Fragment method
            return new selectorRecycler.MyDataVHolder(li, parent);
        }

        @Override
        public void onBindViewHolder(selectorRecycler.MyDataVHolder vh, int index)
        {
            position = index;
            vh.bind(structures[position], index);
        }

    }

    private class MyDataVHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        public MyDataVHolder(LayoutInflater li, ViewGroup parent) {
            super(li.inflate(R.layout.selector_fragment,
                    parent, false));

            imageView =(ImageView)itemView.findViewById(R.id.structure);
        }

        public void bind(int data, final int position) // Called by your adapter
        {

            imageView.setImageResource(data);
            imageView.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            //Simply sets selected to the current drawable so that mapRecycler can access it using static instance
                            mapRecycler.getInstance().setDetails(false);
                            selected = structures[position];



                        }
                    }
            );
        }


    }


}
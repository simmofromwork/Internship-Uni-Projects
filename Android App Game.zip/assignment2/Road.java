package curtin.edu.au.assignment2;

public class Road extends Structure {

    private int cost;

    public Road() {
        super();
        cost = Settings.getInstance().getRoadBuildingCost();
    }


    public int getCost(){
        return cost;
    }

}

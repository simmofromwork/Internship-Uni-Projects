package curtin.edu.au.assignment2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DecimalFormat;

//This fragment displays the population and employment rate for the city.
public class stats2 extends Fragment {

    private TextView population, empRate;
    public stats2() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_stats2, container, false);
        Settings settings = GameData.getInstance().getSettings();
        population = (TextView)view.findViewById(R.id.pop);
        empRate = (TextView)view.findViewById(R.id.empRate);
        //Round the employment rate to two decimal places
        DecimalFormat df = new DecimalFormat("####0.00");

        population.setText("  Population: "+Integer.toString(settings.getPopulation()));
        empRate.setText("     EmploymentRate: " + df.format(settings.getEmployment()));

        return view;
    }
}
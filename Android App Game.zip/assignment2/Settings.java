package curtin.edu.au.assignment2;

import android.os.Build;



import static java.lang.Double.min;

public class Settings {
    private int mapWidth;
    private int mapHeight;
    private int initialMoney;
    private int familySize;
    private int shopSize;
    private int salary;
    private double taxRate;
    private int serviceCost;
    private int houseBuildingCost;
    private int commBuildingCost;
    private int roadBuildingCost;
    private static Settings settings;

    private Settings(){
        mapWidth = 50;
        mapHeight = 10;
        initialMoney = 1000;
        familySize = 4;
        shopSize = 6;
        salary = 10;
        taxRate = 0.3;
        serviceCost = 2;
        houseBuildingCost= 100;
        commBuildingCost = 500;
        roadBuildingCost = 20;
    }
    public static Settings getInstance(){
        if(settings == null){
            settings = new Settings();
        }
        return settings;
    }


    public Settings(int inWidth, int inHeight, int inMoney){
        mapWidth = inWidth;
        mapHeight = inHeight;
        initialMoney = inMoney;
        familySize = 4;
        shopSize = 6;
        salary = 10;
        taxRate = 0.3;
        serviceCost = 2;
        houseBuildingCost= 100;
        commBuildingCost = 500;
        roadBuildingCost = 20;
    }

    public int getWidth(){
        return mapWidth;
    }

    public int getHeight(){
        return mapHeight;
    }

    public int getMoney(){
        return initialMoney;
    }

    public int getHouseBuildingCost(){
        return houseBuildingCost;
    }

    public int getCommBuildingCost(){
        return commBuildingCost;
    }

    public int getRoadBuildingCost(){
        return roadBuildingCost;
    }

    public void setWidth(int inWidth){
        mapWidth = inWidth;
    }

    public void setHeight(int inHeight){
        mapHeight = inHeight;
    }

    public void setMoney(int inMoney) {
        initialMoney = inMoney;
    }

    //This calculates the the current money plus the income for this timestep and returns the new amount of money
    public int timeStep(int inMoney){
        //Number of residential and commercial buildings
        int nComm = GameData.getInstance().getnComm();
        int nRes = GameData.getInstance().getnRes();

        int population = familySize*nRes;
        double employmentRate = 0;
        if(population>0) {
            employmentRate = min(1, nComm * (double)shopSize / population);
        }
        inMoney += population * (employmentRate * salary * taxRate - serviceCost);
        return inMoney;
    }

    public int getPopulation(){
        return familySize*GameData.getInstance().getnRes();
    }

    public double getEmployment(){
        double employmentRate = 0;
        if(getPopulation() != 0) {
            employmentRate = min(1, GameData.getInstance().getnComm() * (double)shopSize / getPopulation());
        }
        return employmentRate;
    }
}

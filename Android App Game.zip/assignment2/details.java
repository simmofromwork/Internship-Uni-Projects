package curtin.edu.au.assignment2;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentManager;

import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

//This class contains the details functionality which displays the coordinates, strucute type, name and allows for a thumbnail image to be taken
public class details extends AppCompatActivity {
    private Button back, btnCam;
    private TextView structureType, coord, nameSaved;
    private EditText name;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        //Declare variables
        back = findViewById(R.id.back);
        structureType = findViewById(R.id.structureType);
        coord = findViewById(R.id.coord);
        name = findViewById(R.id.name);
        nameSaved = findViewById(R.id.nameSaved);

        //Declare gamedata variables for use
        int position = mapRecycler.getInstance().getMapPos();
        final int row = position % GameData.getInstance().getHeight();
        final int col = position / GameData.getInstance().getHeight();
        int imageId = GameData.getInstance().getMap()[row][col].getStructure().getImageId();

        //Initialise the different textviews that show the details
        nameSaved.setText("Name: "+ GameData.getInstance().getMap()[row][col].getOwnerName());
        structureType.setText("Structure Type: "+getType(imageId));
        coord.setText("Coordinates : ("+row+", "+ col+")");
        btnCam = findViewById(R.id.btnCam);


        back.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //Make sure that the editText is not empty, then save the input
                        if(!(name.getText().toString().equals(""))){
                            GameData.getInstance().getMap()[row][col].setOwnerName(name.getText().toString());
                            nameSaved.setText(GameData.getInstance().getMap()[row][col].getOwnerName());
                        }
                        //setDetails tells the map activity whether details has been selected or not, we set it to false before leaving.
                        mapRecycler.getInstance().setDetails(false);
                        finish();

                    }

                }

        );

        //Activates the camera fragment
        btnCam.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        FragmentManager fm = getSupportFragmentManager();
                        camera camera = (camera) fm.findFragmentById(R.id.deets);
                        if(camera == null){
                            camera = new camera();
                            fm.beginTransaction().add(R.id.deets, new camera(row, col)).commit();
                        }


                    }

                }

        );




    }

    //Simply finds the type of structure that is being inquired about
    private String getType(int inId){
        String type = "empty";
        if(StructureData.getInstance().isCommercial(inId)){
            type = "Commercial";
        }
        else if(StructureData.getInstance().isResidential(inId)){
            type = "Residential";
        }
        else if(StructureData.getInstance().isRoad(inId)){
            type = "Road";
        }
        return type;

    }
}
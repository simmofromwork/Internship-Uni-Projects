public class UnitTestProcessGraph
{
    public static void main(String [] args)
    {
        /*ProcessGraph is the core of interactive and simulationMode.
        fillTimeStepRec is most easily tested by running interactive mode and 
        selecting display statistics at each timeStep update. This way you can
        view the timeStep information and see if its working.
        
        To test the different process methods such as processStrict, 
        processModerate and process Connection. Run an infection in interactive
        mode and check the list of names for each category at the end.
        If run on strict(S), only people with essential or family connections 
        will have had a chance of infection. For moderate(M) all people have a 
        chance of infection except those with recreational (R) relationships. 
        The people excluded based on the type of processing will remain in the 
        Susceptible list for all timeSteps.*/

        //Testing random number generating function
        try
        {
            System.out.println("input 0.5 death chance. Repeat 6 times: \n"+ processGraph.deathChance(0.5));
            System.out.println(processGraph.deathChance(0.5));
            System.out.println(processGraph.deathChance(0.5));
            System.out.println(processGraph.deathChance(0.5));
            System.out.println(processGraph.deathChance(0.5));
            System.out.println(processGraph.deathChance(0.5)); 
        }catch (Exception e){System.out.println("random number generator failed" + e.getMessage());}   
        //Run this several times to show randomisation.
     
    }
}

//DSALinkedList is a generic linked list written in a previous practical

import java.util.*;
import java.io.*;
public class DSALinkedList implements Iterable, Serializable
{
    private DSAListNode head, tail;

    //private DSAListNode//
    public Iterator iterator()
    {
        return new DSALinkedListIterator(this);
    }

    private class DSALinkedListIterator implements Iterator, Serializable
    {
        private DSAListNode iterNext;
        
        public DSALinkedListIterator(DSALinkedList theList)
        {
            iterNext = theList.head;       
        }
        public boolean hasNext()
        {
            return (iterNext != null);
        }
        
        public Object next()
        {
            Object value;
            if(iterNext == null)
            {
                value = null;
            }
            else
            {
                value = iterNext.getValue();
                iterNext = iterNext.getNext();
            }
            return value;
        }
        public void remove()
        {
            throw new UnsupportedOperationException("not supported");
        }
        
    }

    private class DSAListNode implements Serializable
    {
        private Object m_value;
        private DSAListNode m_next;
        private DSAListNode m_prev;
        
        public DSAListNode(Object inValue)
        {
            m_value = inValue;
            m_next = null;
            m_prev = null;
        }
        
        public Object getValue()
        {
            return m_value;
        }

        public void setValue(Object inValue)
        {
            m_value = inValue;
        }

        public DSAListNode getPrev()
        {
            return m_prev;        
        }

        public void setPrev(DSAListNode newPrev)
        {
            m_prev = newPrev;
        }        

        public DSAListNode getNext()
        {
            return m_next;
        }
    
        public void setNext(DSAListNode newNext)
        {
            m_next = newNext;
        }

    }
    
    
    public DSALinkedList()
    {
        head = null;
        tail = null;
    }

    //Mutators

    public void insertFirst(Object newValue)
    {
        DSAListNode newNd = new DSAListNode(newValue);
        DSAListNode currNd = new DSAListNode(null);
        if(isEmpty())
        {
            head = newNd;
        }
        else if(head.getNext() == null)
        {
            newNd.setNext(head);
            head = newNd;   
            tail = head.getNext();
        }
        else
        {
            newNd.setNext(head);
            head = newNd;
        }
    }

    public void insertLast(Object newValue)
    {
        DSAListNode newNd = new DSAListNode(newValue);
        DSAListNode currNd = new DSAListNode(null);
        if(isEmpty())
        {
            head = newNd;
        }
        else if(head.getNext() == null)
        {
            currNd = head;
            currNd.setNext(newNd);
            newNd.setPrev(head);
            tail = newNd;
        }
        else
        {
            currNd = tail;
            currNd.setNext(newNd);
            newNd.setPrev(tail);
            tail = newNd;
        }
            
    } 

    //Accessors
    public boolean isEmpty()
    {
        boolean empty = false; 
        if(head == null)
        {
            empty = true;
        }
        return empty;
    }

    public Object peekFirst()
    {
        Object nodeValue;
        if(isEmpty()){
            nodeValue = null;    
        }
        else
        {
            nodeValue = head.getValue();
        }
        return nodeValue;
    }

    public Object peekLast()
    {
        Object nodeValue = null;
        if(isEmpty())
        {
            nodeValue = null;
        }
        else
        {
            nodeValue = tail.getValue();
        }
        return nodeValue;
    }
        //mutators

        public Object removeFirst()
        {
            Object nodeValue = null;
            if(isEmpty())
            {
                head.setValue(null);
            }
            else if(head == tail)
            {
                nodeValue = tail.getValue();
                head = null;
                tail = null;
            }
            else
            {    
                nodeValue = head.getValue();
                head = head.getNext();
            }
            return nodeValue;
        }

        public Object removeLast()
        {
            DSAListNode currNd = new DSAListNode(null);
            DSAListNode prevNd = new DSAListNode(null);
            Object nodeValue = null;
            if(isEmpty())
            {
                head.setValue(null);
            }
            else if(head.getNext() == null)
            {
                nodeValue = head.getValue();
                head = null;
            }
            else
            {
                nodeValue = tail.getValue();
                tail = tail.getPrev();        
            }
            return nodeValue;
        }
        
/*        public Object remove(Object inValue)
        {
            DSAListNode currNd = new DSAListNode(null);
            DSAListNode prevNd = new DSAListNode(null);
            DSAListNode nextNode = new DSAListNode(null);
            Object nodeValue = null;
            if(isEmpty())
            {
                head.setValue(null);
            }
            else if
            {
                nodeValue = head.getValue();
                head = null;
            }
            else
            {
                nodeValue = tail.getValue();
                tail = tail.getPrev();        
            }
            return nodeValue;

        }*/
    
} 


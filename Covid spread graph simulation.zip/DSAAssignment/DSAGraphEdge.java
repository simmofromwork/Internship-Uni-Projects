import java.util.*;
import java.io.*;
public class DSAGraphEdge implements Serializable
{
    //Classfields
    private String from, to;
    private char value;
    private String label;
    //Constructor
    public DSAGraphEdge(String fromVertex, String toVertex, String inLabel, char inValue)
    {
        from = fromVertex;
        to = toVertex;
        label = inLabel;
        value = inValue;
    }
    
    //Accessors
    public String getLabel()
    {
        return label;
    }

    public char getValue()
    {
        return value;
    }
    
    public String getFrom()
    {
        return from;
    }

    public String getTo()
    {
        return to;
    }
}

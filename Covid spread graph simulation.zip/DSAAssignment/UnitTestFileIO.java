public class UnitTestFileIO
{
    public static void main(String [] args)
    {
        int numPass = 0;
        int numTests = 4;
        DSAGraph graph = new DSAGraph();
        DSAGraph graph2;
        Person person = new Person("Simon", 21,0);
        graph.addVertex("Simon", person); 
        
        //testing serialize (All just open a serialized file in the program to check)
        try
        {
            System.out.println("Testing serialize.");
            fileIO.serialize(graph, "newFile.txt");    
            numPass++;
            System.out.println("Passed");
        }catch (Exception e){System.out.println("Serialize failed" + e.getMessage());}

        //Test deserialize
        try
        {
            System.out.println("Testing deserialize");
            graph2 = fileIO.deserialize("newFile.txt");    
            numPass++;
            System.out.println("Passed");
            System.out.println("Show both graphs are the same: \ngraph1: "); 
            interactiveMode.displayNetwork(graph);  
            System.out.println("\ngraph2:"); 
            interactiveMode.displayNetwork(graph2);
        }catch (Exception e){System.out.println("deserialize failed" + e.getMessage());}

        //Test readPerson
        try
        {
            System.out.println("Testing readPerson by reading a list of names and displaying the graph: ");
            graph = fileIO.readPerson("names.txt");
            interactiveMode.displayNetwork(graph);
            numPass++;
            System.out.println("Passed");
        }catch(Exception e){System.out.println("read person failed " + e.getMessage());}

        //Test readEdges
        try
        {
            System.out.println("Testing readEdges by reading in and displaying graph: ");
            graph = fileIO.readEdges("joins.txt", graph);
            interactiveMode.displayNetwork(graph);
            numPass++;
            System.out.println("Passed");
        }catch(Exception e){System.out.println(" " + e.getMessage());}

        System.out.println("PASSED : " + numPass+"/"+numTests);

    }

}

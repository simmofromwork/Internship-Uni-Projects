/*
DSAGraph class is a modified version of previously written code. 
*/
import java.util.*;
import java.io.*;
public class DSAGraph implements Serializable
{
    //Classfield
    private DSALinkedList vertices;
    private DSALinkedList edges;
    private int vertexCount;
    private int edgeCount;
    private double trans;
    private double recov;
    private char intCode;
    private double death;
    private int deathCount;
    //Constructor
    public DSAGraph()
    {
        vertices = new DSALinkedList();
        edges = new DSALinkedList();
        vertexCount = 0;
        edgeCount = 0;
        deathCount = 0;
        trans = 0;
        recov = 0;
        intCode = 'N';
        death = 0;
    }
   //Mutators 
    public void setCode(char code)
    {
        intCode = code;
    }

    public void setTrans(double inTrans)
    {
        trans = inTrans*setRate(intCode);
    }

    public void setRecov(double inRecov)
    {
        recov = inRecov;
    }

    public void setDeath(double inDeath)
    {
        death = inDeath;
    }

    public void incDeathCount()
    {
        deathCount++;
    }    
    
    public void setDeathCount(int inCount)
    {
        deathCount = inCount;
    }
    //Adjusts the recovery and transmission rates depeding on the intervention code given
    private double setRate(char intCode)
    {
        double intervention=1;
        if(intCode == 'S')
        {
            intervention = 0.5;    
        }
        else if(intCode == 'M')
        {
            intervention = 0.75;
        }
        else if(intCode == 'R')
        {
            intervention = 0.9;
        }
        return intervention;
    }
    
    //Accessors    
    public int getDeathCount()
    {
        return deathCount;
    }

    public double getRecov()
    {
        return recov;   
    }

    public double getTrans()
    {
        return trans;
    }
        
    public char getCode()
    {
        return intCode;
    }
    
    public double getDeath()
    {
        return death;
    }
    

    public int getVertexCount() 
    {
        return vertexCount;
    }

    public int getEdgeCount()
    {
        return edgeCount;
    }
   
    public DSALinkedList getVertices()
    {
        return vertices;
    }    
 
    public DSAGraphVertex getVertex(String label)
    {
        DSAGraphVertex vertex;
        vertex = iterateOver(vertices, label);
        return vertex;
    }
    
    public DSAGraphEdge getEdge(DSAGraphVertex vertex1, DSAGraphVertex vertex2)
    {
        DSAGraphEdge edge=null;
        if(hasEdge(vertex1.getLabel(),vertex2.getLabel()))
        {
            edge = iterateOverEdge(edges, vertex1.getLabel()+vertex2.getLabel());
        }
        else if(hasEdge(vertex2.getLabel(),vertex1.getLabel()))
        {
            edge = iterateOverEdge(edges, vertex2.getLabel()+vertex1.getLabel());
        }
        return edge;
    }
    
    public DSALinkedList getAdjacent(String label)
    {
        return getVertex(label).getAdjacent();
    }    
    
    //Adding edges or vertices
    public void addVertex(String label, Person value)
    {
        if(!(hasVertex(label)))
        {
            DSAGraphVertex vertex = new DSAGraphVertex(label, value);
            vertices.insertLast(vertex);
            vertexCount++;
        }
    } 
    
    public void addEdge(String label1, String label2, char type)
    {
        DSAGraphEdge edge = new DSAGraphEdge(label1, label2, label1+label2, type);
        edges.insertLast(edge);
        addEdgeVertex(label1, label2);
        edgeCount++;        

    }

    public void addEdgeVertex(String label1, String label2)
    {    
        DSAGraphVertex v1, v2;
        v1 = getVertex(label1);
        v2 = getVertex(label2);
        v2.getAdjacent().insertLast(v1);
        v1.getAdjacent().insertLast(v2);
        
    }
    //Other methods
    public boolean hasVertex(String label)
    {
        boolean result = false;
        if(iterateOver(vertices, label) != null)
        {
            result = true;
        }
        return result;
    }
    
    
    
    public boolean hasEdge(String label1, String label2)
    {
        boolean result = false;
        if(iterateOverEdge(edges, label1 + label2)!= null)
        {
            result = true;
        }
        return result;
    } 
    
    public boolean hasAdjVertex(DSALinkedList list, String label)
    {
        boolean result = false;
        if(iterateOver(list, label) != null)
        {
            result = true;
        }
        return result;

    }     

    public void markAllNew(DSALinkedList list)
    {
        Iterator iter = list.iterator();
        DSAGraphVertex vertex;
        while(iter.hasNext())
        {
            vertex = (DSAGraphVertex)iter.next();
            vertex.clearVisited();
        }
    }
    

    public DSAGraphEdge iterateOverEdge(DSALinkedList ll, String label)
    {
        DSAGraphEdge c = null;
        Iterator iter = ll.iterator();
        while((iter.hasNext()) && (c == null))
        {
            c = (DSAGraphEdge)iter.next();
            if(!(c.getLabel().equals(label)))
            {
                c = null;
            }
                
        }
        return c;

    }

    public DSAGraphVertex iterateOver(DSALinkedList ll, String label)
    {
        DSAGraphVertex c = null;
        Iterator iter = ll.iterator();
        while((iter.hasNext()) && (c == null))
        {
            c = (DSAGraphVertex)iter.next();
            if(!(c.getLabel().equals(label)))
            {
                c = null;
            }
                
        }
        return c;
    }

    public void displayVertices()
    {
        DSAGraphVertex c = null;
        Iterator iter = vertices.iterator();
        while(iter.hasNext())
        {
            c = (DSAGraphVertex)iter.next();
            System.out.println(c.getLabel() + " " + c.getValue());
        }
    }


}

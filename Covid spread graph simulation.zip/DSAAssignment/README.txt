Author: Simon Hughes
Date: 30/05/2020
Program: HealthSim
Purpose: 
    To simulate the spread of disease based on the SIR model. The program 
    constructs a graph out of peoples names and connections to each other and 
    simulates a spread between these people based on various different 
    parameters.

All files:
    
    DSAGraph.java
    DSAGraphVertex.java
    DSAGraphEdge.java
    DSALinkedList.java
    fileIO.java
    interactiveMode.java
    simulationMode.java
    healthSim.java
    processGraph.java
    Person.java
    TimeStep.java
    userInterface.java

How to Run the Program
    
    InteractiveMode:
        Execute like: java healthSim -i
        
        When interactiveMode is executed it first asks if you want to load a 
        serialised network, or construct a new network from two CSV files. The 
        two CSV files are in the same format as simulation mode.(see below)
        After loading a graph through one of the two methods above, the user 
        can set the graph variables and then run a new infection. After running
        a new infection the user can update timesteps and look at the 
        statistics and lists for each step as they please. 
        Other options are available on the menu.

    SimulationMode:
        Execute like: java healthSim -s namesfile edgesFile trans_rate 
        recov_rate death_rate int_code.
        Where namesFile is a list of people in CSV format e.g. name,age,state.
        Where edgeFile is a CSV in the format name1,name2,type.
        The newly constructed network is then written to a file with a name 
        specified by the user.
    
    Usage:
        Executing the program with no additional command-line paramenter will 
        result and some usage information being displayed to the user.



File Descriptions

    DSALinkedList.java:
        DSALinkedList was written in an earlier practical session and consists
        of DSAListNodes(private inner class) that have a value and a pointer to
        the next node.

    DSAGraph.java:
        DSAGraph is a graph data structure that was written as a part of 
        practical 6 in DSA. It consists of a lined list of vertex objects. 
        The vertex objects have their own linked list of connections to other 
        vertices.  
        DSAGraph has been modified to store the transmission rate, recovery 
        rate, death rate and intervention code.

    DSAGraphVertex.java:
        DSAGraphVertex objects are the nodes that occupy the DSAGraph vertices 
        linked list. The class is also from practical 6 in DSA.

    DSAGraphEdge.java:
        DSAGraphEdge objects are stored in the DSAGraph edges linked list. 
        Edges consist of two vertices and a weighting.

    fileIO.java:
        This class is responsible for reading csv files and instantiating graph
        objects from them, as well as reading and writing serialized graph 
        objects.

    interactiveMode.java:
        This class contains all the methods that are called from the 
        interactiveMode user interface. The methods include creating a timestep
        list and calculating all of the statistics based on this list.

    simulationMode.java:
        This class essentially works on the same methods as interactiveMode 
        but instead outputs the timeStep states and population statistics to a
        textfile.

    healthSim.java:
        HealthSim contains the main method to the program and takes in a
        variable number of command-line arguments depeding on what mode the 
        user wants to execute the program in.

    processGraph.java:
        This class is contains all of the methods involved in the actual 
        simulation algorithm. When the user elects to start a 'New infection' 
        or inputs values for simulationMode, processGraph.java converts the 
        graph network into a list of timeStep objects. It takes into account
        tranmission, recovery and death rate probabilities as well as 
        intervention codes and different types of relationships between people.
    
    Person.java:
        This is an object class and forms the basis for the value stored in 
        each vertex of the graph. A person has many attributes including name, 
        age, state, health status, date infected and date recovered.

    TimeStep.java:
        This class is an object class that consists of a linked list of 
        Susceptible, Infected and Removed. It also stores a LocalDate object 
        and visited boolean to keep track of which timestep the program is up 
        to. These timeStep lists are populated and the timestep inserted into 
        a linked list so that all timeSteps can be kept track of in a 
        sequential fashion.

    userInterface.java:    
        The userInterface class contains the main menus for interactive mode.
        


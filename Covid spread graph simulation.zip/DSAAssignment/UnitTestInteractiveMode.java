public class UnitTestInteractiveMode
{
    public static void main(String [] args)
    {
        System.out.println("InteractiveMode is best tested by executing it.\nTo check the rates you input and intCode, simply select displaystats, after running an infection. Bearing in mind that\nthe transmission rate is affected by the intCode so it may not be exactly what you entered. intCodes:\nS(Strict) will *0.5. M(Moderate) will *0.75. R(Relaxed) will *0.85. Enter any other character will not affect the transmission rate.\nTo test display network, execute in interactive mode, load a graph and select display network");
     
    }
}

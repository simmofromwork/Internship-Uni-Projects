import java.util.*;
import java.time.*;
public class UnitTestTimeStep
{
    public static void main(String [] args)
    {
        DSALinkedList list = new DSALinkedList();
        LocalDate date = LocalDate.now();
        TimeStep timeStep=null;
        Person person = new Person("Simon", 21, 0);
        int numPass = 0;
        int total = 3;
        //Test constructor
        try
        {
            System.out.println("Testing constructor");
            timeStep = new TimeStep(date);
            numPass++;
            System.out.println("Passed");
        }catch (Exception e) {System.out.println("Constructor failed " +e.getMessage());}
        
        //Testing add methods which add a person to specified list
        try
        {
            System.out.println("Testing add to lists");
            timeStep.addSus(person.getName());
            timeStep.addRem(person.getName());
            timeStep.addInf(person.getName());
            numPass++;
            System.out.println("Passed");
        }catch(Exception e){System.out.println("Add to list failed " + e.getMessage());}
        //hasSus
        try
        {
            System.out.println("Testing hasSus");
            if(timeStep.hasSus(person.getName()))
            {
                numPass++;
                System.out.println("Passed");
            }
        }catch(Exception e){System.out.println("hasSus failed " + e.getMessage());}
        System.out.println("Passed "+ numPass+"/" + total);    
    }
}

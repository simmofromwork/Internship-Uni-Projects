import java.util.*;
import java.time.*;
import java.io.*;
public class TimeStep implements Serializable
{
    private DSALinkedList Sus, Inf, Rem;
    LocalDate date;
    private int remCount, susCount, infCount, total, deathCount;
    private boolean visited;
    
    public TimeStep(LocalDate inDate)
    {
        Sus = new DSALinkedList();
        Inf = new DSALinkedList();
        Rem = new DSALinkedList();
        date = inDate;
        remCount = 0;
        susCount = 0;
        infCount = 0;
        deathCount = 0;
        visited = false;
        
    }
    
    public boolean hasSus(String name)
    {
        String match;
        boolean valid = false;
        Iterator iter = Sus.iterator();
        while(iter.hasNext())
        {
            match = (String)iter.next();
            if(match.equals(name))
            {
                valid = true;
            }
        }
        return valid;
    }
   
    public void setDeathCount(int inCount)
    {
        deathCount = inCount;
    }

 
    public void addSus(String name)
    {
        Sus.insertLast(name);
        susCount++;
    }

    public void addInf(String name)
    {
        Inf.insertLast(name);
        infCount++;
    }

    public void addRem(String name)
    {
        Rem.insertLast(name);
        remCount++;
    }

    public void setDate(LocalDate inDate)
    {
        date = inDate;
    }
    
    public DSALinkedList getSus()
    {
        return Sus;
    }

    public DSALinkedList getInf()
    {
        return Inf;
    }

    public DSALinkedList getRem()
    {
        return Rem;
    }

    public int getRemCount()
    {
        return remCount;
    }

    public int getInfCount()
    {
        return infCount;
    }

    public int getSusCount()
    {
        return susCount;
    }
    
    public int getDeathCount()
    {
        return deathCount;
    }    

    public int getTotal()
    {
        return (susCount+ infCount + remCount);
    }
    
    public LocalDate getDate()
    {
        return date;
    }

    public boolean getVisited()
    {
        return visited;
    }    

    public void setVisited()
    {
        visited = true;
    }
    
    public void setUnvisited()
    {
        visited = false;
    }
}

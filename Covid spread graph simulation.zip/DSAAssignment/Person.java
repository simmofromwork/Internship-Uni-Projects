import java.util.*;
import java.time.*;
import java.io.*;
public class Person implements Serializable 
{
    //state will be 0 for Sus, 1 for Inf and -1 for Rem
    private String name;
    private int age;
    private LocalDate dateInf;
    private LocalDate dateRem;
    private int state;
    private String hStatus;

    public Person()
    {
        name = "name";
        age = 0;
        dateInf = null;
        dateRem = null;
        state = 0;
        hStatus = "hStatus";
    }    

    public Person(String inName, int inAge, int inState)
    {
        name = inName;
        age = inAge;
        dateInf = null;
        dateRem = null;
        state = inState;
        hStatus = "Susceptible";
    }

    //Accessors
    public String getName()
    {
        return name;
    }

    public int getAge()
    {
        return age;
    }

    public LocalDate getDateInf()
    {
        return dateInf;
    }

    public LocalDate getDateRem()
    {
        return dateRem;
    }

    public int getState()
    {
        return state;
    }

    public String getHStatus()
    {
        return hStatus;
    }

    //Mutators
    public void setName(String inName)
    {
        name = inName;
    }

    public void setAge(int inAge)
    {
        age = inAge;
    }

    public void setDateInf(LocalDate inDateInf)
    {
        dateInf = inDateInf;
    }

    public void setDateRem(LocalDate inDateRem)
    {
        dateRem = inDateRem;
    }

    public void setState(int inState)
    {
        state = inState;
    }

    public void setHStatus(String inHStatus)
    {
        hStatus = inHStatus;
    }

    public String toString()
    {
        String toString;
        toString = "name : "+name+"\nage : "+age+"\nDate infected : "+dateInf+"\nDate removed : "+dateRem+"\nHealth status : "+hStatus;
        return toString;
    }

}

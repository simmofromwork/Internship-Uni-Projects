//DSAGraphVertex is from a previous practical

import java.util.*;
import java.io.*;
public class DSAGraphVertex implements Serializable
{
    private String label;
    private Person value;
    private DSALinkedList vertexList;
    private boolean visited;
    //Constructor
    public DSAGraphVertex(String inLabel, Person inValue)
    {
        label = inLabel;
        value = inValue;
        vertexList = new DSALinkedList(); 
        visited = false;
    }    

    public String getLabel()
    {
        return label;
    }

    public Person getValue()
    {
        return value;
    }
    
    public DSALinkedList getAdjacent()
    {
        return vertexList;
    }
    
    public void setVisited()
    {
        visited = true;
    }
    
    public void clearVisited()
    {
        visited = false;
    }

    public boolean getVisited()
    {
        return visited;
    }
    
    public String toString()
    {
        String toString ="label =" + label + ", value = " + value + ", links =" ;
        return toString; 
    } 
    
    public void displayLinks()
    {
        DSAGraphVertex c; 
        Iterator iter = vertexList.iterator();
        while(iter.hasNext())
        {
            c = (DSAGraphVertex)iter.next();
            System.out.println(c.getLabel());
        }
    }

    
}    

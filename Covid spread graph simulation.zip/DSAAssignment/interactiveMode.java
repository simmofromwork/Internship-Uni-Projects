import java.util.*;
import java.time.*;
public class interactiveMode
{
   //**************************************************************************************//
    /* Node/Edge Operations: The following methods are for adding/removing nodes or edges. */
    //**************************************************************************************//

    //This is the user menu for node operations
    public static void nodeOperations(DSAGraph graph)
    {
        int choice = 3;
        Scanner sc = new Scanner(System.in);
        do
        {
            try
            {
                System.out.println("1. Add Node\n2. Remove Node\n3. Find person\n4. Infect person\n0. Exit");
                choice = sc.nextInt();
            }catch (InputMismatchException e){System.out.println("Wrong input");}
            sc.nextLine();
            switch(choice)
            {
                case 1:
                    addNode(graph);
                break;
                case 2:
                    removeNode(graph);
                break;
                case 3:
                    searchPerson(graph);
                break;
                case 4:
                    infectPerson(graph);
                break;
                case 0:
                break;
                default:
                    System.out.println("Enter a valid choice");
            }
        }while(choice != 0);
    }
    
    private static void removeNode(DSAGraph graph)
    {
        
    }
    //Gets user input and adds new vertex accordingly
    private static void addNode(DSAGraph graph)
    {
        Person person;
        String name = null;
        int age = 0;
        int state = 0;
        Scanner sc = new Scanner(System.in);
        try
        {
            System.out.println("Enter persons name: ");
            name = sc.nextLine();
            System.out.println("Age: ");
            age = sc.nextInt();
            System.out.println("State: (1 for infected, 0 for susceptible)");
            state = sc.nextInt();
            person = new Person(name, age, state);
            graph.addVertex(name, person);
        }catch (InputMismatchException e){System.out.println("faulty input" + e.getMessage());}
    }
    

    //This method infects a selected individual    
    public static void infectPerson(DSAGraph graph)
    {
        String name;
        DSAGraphVertex vertex;
        Scanner sc = new Scanner(System.in);
        System.out.println("\nEnter persons name:");
        name = sc.nextLine();
        vertex = graph.getVertex(name);
        if(vertex != null)
        {
            vertex.getValue().setState(1);
            System.out.println(name + ": infected!");
        }
        else
        {
            System.out.println("No match found.");
        }        
    }


    
    //This is the user menu for edge operations
    public static void edgeOperations(DSAGraph graph)
    {
        int choice = 3;
        Scanner sc = new Scanner(System.in);
        do
        {
            try
            {
                System.out.println("1. Add Edge\n2. Remove Edge\n");
                choice = sc.nextInt();
            }catch (InputMismatchException e){System.out.println("Wrong input");}
            sc.nextLine();
            switch(choice)
            {
                case 1:
                    addEdge(graph);
                break;
                case 2:
                    removeEdge(graph);
                break;
                case 0:
                break;
                default:
                    System.out.println("Enter a valid choice");
            }
        }while(choice != 0);
 
    }
    

    //Asks for user input and adds the new edge to list of edges    
    public static void addEdge(DSAGraph graph)
    {
        String name1 = null;
        String name2 = null;
        char type = 'N';
        Scanner sc = new Scanner(System.in);
        try
        {
            System.out.println("Enter first name: ");
            name1 = sc.nextLine();
            System.out.println("Enter second name ");
            name2 = sc.nextLine();
            System.out.println("Enter edge type: ");
            type = sc.nextLine().charAt(0); 
            graph.addEdge(name1, name2, type);
        }catch (InputMismatchException e){System.out.println("faulty input" + e.getMessage());}
    
    }

    public static void removeEdge(DSAGraph graph)
    {

    }

    
    //************************************************************************************//
    /* Display methods: The following methods are for displaying the graph or statistics */
    //************************************************************************************//

    //This method displays the graph as an adjacency list
    public static void displayNetwork(DSAGraph graph)
    {
        if(graph != null)
        {
            DSAGraphVertex vertex1, vertex2;
            Iterator iter = graph.getVertices().iterator();
            while(iter.hasNext())    
            {
                vertex1 = (DSAGraphVertex)iter.next(); 
                System.out.print(vertex1.getLabel() + " :");
                Iterator iterAdj = vertex1.getAdjacent().iterator();
                while(iterAdj.hasNext())
                {
                    vertex2 = (DSAGraphVertex)iterAdj.next();
                    System.out.print(" " + vertex2.getLabel());
                }
                System.out.println("\n");
            
            }
        }
        else
        {
            System.out.println("You must load a graph before trying to access this data.");
        }

    }
    

    //This method is the user interface for displaying statistics
    public static void displayStats(DSAGraph graph, TimeStep currTimeStep, DSALinkedList timeStepList)
    {
        if(timeStepList != null)
        {
            int choice=10;
            Scanner sc = new Scanner(System.in);
            if(currTimeStep == null)
            {
                currTimeStep = update(timeStepList);
            }
                do
                {   
                    try
                    {
                        System.out.println("\n\nRATES\nTransmission: " + graph.getTrans()+"\nRemoval: " + graph.getRecov()+"\nDeath: "+ graph.getDeath()+"\nIntervention: "+graph.getCode()+ "\n1. Population Statistics\n2. List of names by Category\n0. Back to Menu");
                        choice = sc.nextInt();
            
                    }catch (InputMismatchException e) {System.out.println("Wrong input type" + e.getMessage());}
                        sc.nextLine();
                    switch(choice)
                    {
                        case 1:
                            System.out.println(population(graph, currTimeStep));
                        break;
                        case 2:
                            printNames(graph, currTimeStep);      
                        break;
                        case 0:
                            System.out.println("GoodBye");
                        break;
                        default:
                            System.out.println("Make sure you enter a valid option");
            
                    }    
                }while(choice !=0);
        }
        else
        {
            System.out.println("You must create a new infection before accessing statistics");
        }
    }
    
    
    //This methods prints the formatted statistics for the population for the current timeStep.
    public static String population(DSAGraph graph, TimeStep timeStep)
    {
        int total = graph.getVertexCount();
        String stats = "\nTimeStep: " + timeStep.getDate() + "\nPopulation size: "+ total +"\nAverage age: " + calcAvAge(graph)+ "\nBy Percentage: "+"\nSusceptible: " + (double)timeStep.getSusCount()/(double)total+"\nInfected: "+(double)timeStep.getInfCount()/(double)total+"\nRecovered "+(double)(timeStep.getRemCount()-timeStep.getDeathCount())/(double)total+"\ndeceased: " + (double)timeStep.getDeathCount()/(double)total; 
        return stats;
    } 
    


    //This method calculates the average age of all persons.
    private static double calcAvAge(DSAGraph graph)
    {
        DSAGraphVertex vertex;
        double age = 0;
        Iterator iter = graph.getVertices().iterator();
        while(iter.hasNext())
        {
            vertex = (DSAGraphVertex)iter.next();
            age += vertex.getValue().getAge();
        }
        age = age/graph.getVertexCount();
        return age;
    }
    

    //Searches graph vertices for a particular person and prints their details.
    public static void searchPerson(DSAGraph graph)
    {
        String name;
        DSAGraphVertex vertex;
        Scanner sc = new Scanner(System.in);
        System.out.println("\nEnter persons name:");
        name = sc.nextLine();
        vertex = graph.getVertex(name);
        if(vertex != null)
        {
            System.out.println("\nName: " + vertex.getLabel() +"\nAge: " + vertex.getValue().getAge() + "\nDate Infected: " + vertex.getValue().getDateInf() + "\nDate Removed: " + vertex.getValue().getDateRem() + "\nHealth Status: " + vertex.getValue().getHStatus()+"\n");
        }
        else
        {
            System.out.println("No match found.");
        }
        
    }
    

    //This method prints the names of each respective list at a particular timeStep.
    public static void printNames(DSAGraph graph, TimeStep timeStep)
    {
        System.out.println("\n"+timeStep.getDate()+ "\nSusceptible:");
        printList(timeStep.getSus());
        System.out.println("\nInfected:");
        printList(timeStep.getInf());
        System.out.println("\nRemoved:");
        printList(timeStep.getRem());
   
    }

    public static void printList(DSALinkedList list)
    {
        String name;
        Iterator iter = list.iterator();   
        while(iter.hasNext()) 
        {
            name = (String)iter.next();
            System.out.println(name);
        }    
    }

    

    
    //***********************************************************************************//
    /* Infection and TimeStep management: Below are the methods responsible for running  */
    /*  an infection and storing the various states in a linked list of timeSteps.       */
    //***********************************************************************************//

    public static DSALinkedList newInfection(DSAGraph graph)
    {
        //Declarations
        DSALinkedList timeStepList = new DSALinkedList();
        LocalDate date = LocalDate.now(); 
        //Creating first infected list to send to fillTimeStepList
        timeStepList = processGraph.fillTimeStepListRec(timeStepList, date, graph);
        return timeStepList;      
    }



    //This method iterates to the next timeStep in the timeStepList
    public static TimeStep update(DSALinkedList timeStepList)
    {
        TimeStep timeStep;
        Iterator iter = timeStepList.iterator();
        do
        {
            timeStep = (TimeStep)iter.next();
        }while(iter.hasNext() && (timeStep.getVisited()));
        if(timeStep.getVisited())
        {
           System.out.println("No more timeSteps");
        } 
        timeStep.setVisited();
        return timeStep;
    }


    
    //***************//
    /* Other methods */
    //***************//
    
    //This method allows the user to set each of the graph variables, which is necessary to run an infection.
    public static void setVars(DSAGraph graph)
    {
        double recov, trans, death;
        char intCode;
        Scanner sc = new Scanner(System.in);
        System.out.println("intervention code: ");
        intCode = sc.next(".").charAt(0);
        graph.setCode(intCode);
        System.out.println("Enter transmission rate: ");
        trans = sc.nextDouble();
        graph.setTrans(trans);
        System.out.println("recovery rate: ");
        recov = sc.nextDouble();
        graph.setRecov(recov);
        System.out.println("Enter death rate:");
        death = sc.nextDouble();
        graph.setDeath(death); 
    }
    
    //This method deserializes an existing file and returns the graph object. 
    public static DSAGraph loadExistingNetwork(String file)
    {
        DSAGraph graph = fileIO.deserialize(file);
        return graph;
    }
    
    //This method passes the graph to be saved into the serialize method from fileIO that saves the graph to a serialized file. 
    public static void saveNetwork(DSAGraph graph)
    {
        Scanner sc = new Scanner(System.in);
        String file;
        System.out.println("Enter filename to save to:");
        file = sc.nextLine();
        fileIO.serialize(graph, file);
    }
                        
   
}

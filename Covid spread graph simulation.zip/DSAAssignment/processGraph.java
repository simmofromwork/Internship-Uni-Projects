import java.util.*;
import java.time.*;
public class processGraph
{
    //NEED TO SEND THE FIRST LIST AND THE EMPTY TIMESTEPLIST AND SORT OUT LONG DATE
    public static DSALinkedList fillTimeStepListRec(DSALinkedList timeStepList, LocalDate date, DSAGraph graph)
    {
        TimeStep timeStep = new TimeStep(date);
        DSAGraphVertex vertex1, vertex2;
        String name1;
        int state = 0;
        Iterator iter = graph.getVertices().iterator();
        //Iterate through list of all vertices
        while(iter.hasNext())
        {
            vertex1 = (DSAGraphVertex)iter.next();
            //If person is infected
            if(vertex1.getValue().getState() == 1 && !vertex1.getVisited())
            {
                graph = processGraph(vertex1,graph, date);
                vertex1 = randRem(vertex1, graph, date);
                if(vertex1.getValue().getHStatus().equals("Deceased"))
                {
                    graph.incDeathCount();
                }   
   
            }
        }                    
        iter = graph.getVertices().iterator();
        while(iter.hasNext())
        {
            vertex1 = (DSAGraphVertex)iter.next();
            state = vertex1.getValue().getState();
            if(state == -1)
            {
                timeStep.addRem(vertex1.getLabel());
            }
            else if(state == 0)
            {
                vertex1.getValue().setHStatus("Susceptible");
                timeStep.addSus(vertex1.getLabel());
            }
            else if(state == 1)
            {
                timeStep.addInf(vertex1.getLabel());
            }
        }
        timeStep.setDeathCount(graph.getDeathCount());
        graph.markAllNew(graph.getVertices());
         //Inserting newly populated timeStep into timeStepList
        timeStepList.insertLast(timeStep);
        if(timeStep.getInfCount() != 0)
        {
            date = date.plusWeeks(2);
            //Recursively calling function with incremented date
            timeStepList = fillTimeStepListRec(timeStepList, date, graph);
        }
        return timeStepList;
    }

   
    //Processes the person based on the strict intervention code 
    private static DSAGraphVertex processStrict(DSAGraphVertex vertex1, DSAGraphVertex vertex2, DSAGraph graph, LocalDate date)
    {
        char type = graph.getEdge(vertex1,vertex2).getValue();
        if(type == 'F' || type == 'E')
        {
            vertex2 = randInf(vertex2, graph.getTrans(), date);       
        }
        return vertex2;
    }
    



    //Processes the peron based on the moderate intervention code by excluding recreational connections
    private static DSAGraphVertex processModerate(DSAGraphVertex vertex1, DSAGraphVertex vertex2, DSAGraph graph, LocalDate date)
    {
        char type = graph.getEdge(vertex1,vertex2).getValue();
        if(type != 'R')
        {
            vertex2 = randInf(vertex2, graph.getTrans(), date);
        }
        return vertex2;
    }
   



    //Takes current vertex that is infected and has not been visited this timeStep, iterates through its connection and passing the susceptible people tp other methods to be processed for infection. 
    public static DSAGraph processGraph(DSAGraphVertex vertex1, DSAGraph graph, LocalDate date)
    {
        DSAGraphVertex vertex2;
        Iterator iter = vertex1.getAdjacent().iterator();
        while(iter.hasNext())
        {
            vertex2 = (DSAGraphVertex)iter.next();
            if(vertex2.getValue().getState() == 0)
            {    
                vertex2 = processConnection(vertex1, vertex2, graph, date);
            }
        }
        return graph;
    }
    
    
    

    //Passes the susceptible people to the correct infection processing method based on the intervention code
    private static DSAGraphVertex processConnection(DSAGraphVertex vertex1, DSAGraphVertex vertex2, DSAGraph graph, LocalDate date)
    {
        if(graph.getCode()== 'S')
        {
            vertex2 = processStrict(vertex1, vertex2, graph, date);
        }
        else if(graph.getCode() == 'M')
        {
            vertex2 = processModerate(vertex1, vertex2, graph, date);
        }
        else
        {   //ProcessRelaxed does not eliminate connections but just relies on a reduced transmission variable
            vertex2 = randInf(vertex2, graph.getTrans(), date);
        }
        return vertex2;
    }    

    

    //Sets all persons to susceptible except for one, so that antoher infection can be run
    public static void makeAllSus(DSAGraph graph)
    {
        Iterator iter = graph.getVertices().iterator();
        DSAGraphVertex vertex= null;
        while(iter.hasNext())
        {
            vertex = (DSAGraphVertex)iter.next();
            vertex.getValue().setState(0);
        }
    
    }

    public static boolean deathChance(double deathRate)
    {
        boolean death = false;
        double rand = Math.random();
        if(rand <= deathRate)
        {
            death = true;
        }

        return death;
    }

    private static DSAGraphVertex randInf(DSAGraphVertex vertex, double trans, LocalDate date)
    {
        int state = 0;
        double rand = Math.random();
        if(rand <= trans)
        {
            vertex.getValue().setState(1);
            vertex.setVisited();
            vertex.getValue().setHStatus("Infected");
            vertex.getValue().setDateInf(date);
        }
        return vertex;
    }
    
    private static DSAGraphVertex randRem(DSAGraphVertex vertex, DSAGraph graph, LocalDate date)
    {
        
        double rand = Math.random();
        if(rand <= graph.getRecov())
        {
            vertex.getValue().setState(-1);
            vertex.getValue().setHStatus("Removed");
            vertex.getValue().setDateRem(date);
            if(deathChance(graph.getDeath()))
            {
                vertex.getValue().setHStatus("Deceased");
            }
        }
        return vertex;
    }
}

import java.util.*;
import java.time.*;
public class userInterface
{
    //This user interface is the intial menu shown to the user when they enter interactive mode. It ensure that first a graph is constructed to be manipulated later by the other menu options.
    public static void loadNetwork()
    {
        int choice = 10;
        Scanner sc = new Scanner(System.in);
        String file;
        DSAGraph graph;
        LocalDate currDate;
        do
        {
            try
            {
                System.out.println("1. Load Serialized Network\n2. Create new Network from CSV Files\n0. Exit");
                choice = sc.nextInt();
            }catch (InputMismatchException e){System.out.println("Wrong input type");}
            sc.nextLine();
            switch(choice)
            {
                case 1:
                    System.out.println("Enter network filename:");
                    file = sc.nextLine();
                    menu(interactiveMode.loadExistingNetwork(file));
                break;
                case 2:
                    System.out.println("Enter Person CSV filename:");
                    file = sc.nextLine();
                    graph = fileIO.readPerson(file);
                    System.out.println("Enter connections filename:");
                    file = sc.nextLine();
                    graph = fileIO.readEdges(file, graph);
                    menu(graph);
                break;
                case 0:
                break;
                default:
                    System.out.println("Enter 1 or 2 or 0");
        
            }
        }while(choice != 0 && choice != 1 && choice != 2);
    }
    

    //This is the main user Interface that the user keep returning to when viewing/manipulating a network.
    public static void menu(DSAGraph graph)
    {
        int choice = 12;
        DSALinkedList timeStepList = null;
        TimeStep currTimeStep = null;
        Scanner sc = new Scanner(System.in);
        do
        {
            System.out.println("(1) Load network\n(2) Set rates/interventions\n(3) Node operations\n(4) Edge operations\n(5) New infection\n(6) Display network\n(7) Display statistics\n(8) Update\n(9) Save network\n(0) Exit");
            try{
                choice = sc.nextInt();
            }catch (InputMismatchException e){
                System.out.println("Not a valid number.");
                sc.nextLine(); 
            }
            switch(choice)
            {
                case 1:
                    loadNetwork();
                break;

                case 2:
                    interactiveMode.setVars(graph);
                break;        
    
                case 3:
                    interactiveMode.nodeOperations(graph);
                break;
                    
                case 4:
                    interactiveMode.edgeOperations(graph);
                break;

                case 5:
                    currTimeStep = null;
                    timeStepList = interactiveMode.newInfection(graph);
                    processGraph.makeAllSus(graph);
                    graph.setDeathCount(1);
                break;

                case 6:
                        interactiveMode.displayNetwork(graph);
                break;
        
                case 7:
                    interactiveMode.displayStats(graph, currTimeStep, timeStepList);
                break;

                case 8:
                    if(timeStepList != null)
                    { 
                        currTimeStep = interactiveMode.update(timeStepList);   
                    }
                    else
                    {
                        System.out.println("There is no infection to update from");
                    }
                break;

                case 9:
                    interactiveMode.saveNetwork(graph);
                break;

                case 0:
                    System.out.println("GoodBye");
                break; 
                default:
                    System.out.println("Make sure you enter one of the integers 0-9 listed.");

            }

        }while(choice != 0 && choice != 1);
    }
}
 

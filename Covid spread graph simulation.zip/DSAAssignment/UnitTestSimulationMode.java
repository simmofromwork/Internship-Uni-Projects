public class UnitTestSimulationMode
{
    public static void main(String [] args)
    {
        System.out.println("Simulation mode can be easily tested by executing the program in\nsimulationMode. The functional parts of the file are also from the fileIO class which has been tested.");

    }    

}

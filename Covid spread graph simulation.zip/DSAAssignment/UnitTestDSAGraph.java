public class UnitTestDSAGraph
{
    public static void main(String [] args)
    {
        DSAGraph graph = new DSAGraph();
        DSAGraph graph1;
        Person person1 = new Person("Simon",21,0);
        Person person2 = new Person("Leila",21,1);
        int numPass = 0;
        int numTests = 8;
        //Constructor
        try
        {
            graph1 = new DSAGraph();
            numPass++;
            System.out.println("passed");
        }catch (Exception e) {System.out.println("constructor failed " + e.getMessage());}   
        //Testing addVertex        
        try
        {
            graph.addVertex("Simon", person1);
            graph.addVertex("Leila", person2);
            numPass++;
            System.out.println("passed");
        }catch (Exception e){System.out.println("addVertex failed " + e.getMessage());}
        //Testing hasVertex
        try{
            System.out.println("hasVertex should be true:" + graph.hasVertex("Simon"));
            numPass++;
            }catch(Exception e){System.out.println("hasvertex failed " + e.getMessage());}
        //Testing getVertex
        try{
            System.out.println("GetVertex Should be Simon: " + graph.getVertex("Simon").getLabel());
            numPass++;
            System.out.println("passed");
        }catch(Exception e){System.out.println("getVertex failed: " + e.getMessage());}
        //Testing addEdge
        try{
            System.out.println("Connecting Simon and Leila with an edge, weight F");
            graph.addEdge("Simon", "Leila", 'F');
            numPass++;
            System.out.println("passed");
        }catch (Exception e){System.out.println("Failed to connect edge" + e.getMessage());}
        
        try{
            System.out.println("Now display connections of Simon which was just added. It should just be Leila: ");
            graph.getVertex("Simon").displayLinks();
            numPass++;
            System.out.println("passed");
        }catch (Exception e) {System.out.println("failed display links : " + e.getMessage());}
            System.out.println("Num tests = 6" + " Num passed = " + numPass);
            System.out.println("currently in graph: ");
            graph.displayVertices();
    
    }

}

import java.util.*;
public class healthSim
{
    public static void main(String [] args)
    {
        if(args.length == 0)
        {
            usageInfo();
        }
        else if(args[0].equals("-i"))
        {
            userInterface.loadNetwork();
        }
        else if(args[0].equals("-s"))
        {
            if(args.length == 7)
            {
                DSAGraph graph;
                graph = simulationMode.readFiles(args[1], args[2]); 
                graph = simulationMode.setGraph(graph, args[3], args[4], args[5], args[6]);
                simulationMode.writeToFile(graph);
            }
            else
            {
                System.out.println("Incorrect number of arguments supplied to the command line.");
            }
        }
    }


    //This method details the usage information of the program when run without any command line parameters
    public static void usageInfo()
    {
        System.out.println("To access simulation mode, execute the program followed by : \nhealthSim -s namesfile edgesFile trans_rate recov_rate death_rate int_code\nWhere namesFile is a list of people in CSV format:\nname,age,state.\nWhere edgeFile is a csv in the format: \nname1,name2,type.\nTo access interactive mode, execute the program followed by -i. e.g java healthSim -i");
    }
    
 
}    

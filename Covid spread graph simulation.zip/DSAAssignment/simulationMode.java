//Write to file found here : https://www.w3schools.com/java/java_files_create.asp


import java.util.*;
import java.io.*;
public class simulationMode
{
    public static DSAGraph readFiles(String names, String joins)
    {
        DSAGraph graph = fileIO.readPerson(names);
        graph = fileIO.readEdges(joins, graph); 
        return graph;
    }


    public static DSAGraph setGraph(DSAGraph graph, String inTrans, String inRecov, String inDeath, String intCode)
    {
        graph.setCode(intCode.charAt(0));
        graph.setTrans(Double.parseDouble(inTrans));
        graph.setRecov(Double.parseDouble(inRecov));
        graph.setDeath(Double.parseDouble(inDeath));
        return graph;  
    }

    public static void writeToFile(DSAGraph graph)
    {
        Scanner sc = new Scanner(System.in);
        DSALinkedList timeStepList;
        TimeStep timeStep;
        timeStepList = interactiveMode.newInfection(graph);
        String name;
        Iterator iter = timeStepList.iterator();
        System.out.println("Enter new filename: e.g newFile.txt");
        name = sc.nextLine();
        try
        {
            File myObj = new File(name);
            if(myObj.createNewFile())
            {
                System.out.println("File created: " + myObj.getName());
                try
                {
                    FileWriter myWriter = new FileWriter(name);
                    
                    while(iter.hasNext())
                    {    
                        timeStep = (TimeStep)iter.next();
                        myWriter.write(interactiveMode.population(graph, timeStep)+ "\n\n");
                    }
                    myWriter.close();
                    System.out.println("File successfully written and saved");
        
                }catch (IOException e){
                    System.out.println("An error occured." + e.getMessage());}
        
            }
            else
            {
                System.out.println("File already exists");
            }

        } catch (IOException e) {
            System.out.println("An error occured." + e.getMessage());}
    }
}

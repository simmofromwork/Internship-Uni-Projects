import java.util.*;
import java.io.*;
public class fileIO
{
    public static DSAGraph deserialize(String file)
    {  
        FileInputStream fileStrm;
        ObjectInputStream objStrm = null;
        DSAGraph inObj=null;

        try{
            fileStrm = new FileInputStream(file);
            objStrm = new ObjectInputStream(fileStrm);
            inObj = (DSAGraph)objStrm.readObject();
            objStrm.close();
        }
        catch (ClassNotFoundException e){
            System.out.println("Class DSAGraph not found");
        }
        catch(IOException e){
            if(objStrm != null)
            {
                try
                {
                    objStrm.close();
                }
                catch (IOException ex2) {}
            }
            System.out.println("Error in file processing: " + e.getMessage());
        }
        return inObj;
    }

    public static void serialize(DSAGraph graph, String file)
    {
        FileOutputStream fileStrm;
        ObjectOutputStream objStrm;
        try{
            fileStrm = new FileOutputStream(file);
            objStrm = new ObjectOutputStream(fileStrm);
            objStrm.writeObject(graph);
            
            objStrm.close();
            }
            catch (IOException e) { 
                throw new IllegalArgumentException("exception thrown" + e.getMessage());
                
            }
              
    }
           
    public static DSAGraph readPerson(String file)
    {
        Person person;
        DSAGraph graph = new DSAGraph();
        FileInputStream fileStrm = null;
        InputStreamReader rdr;
        BufferedReader bufRdr;
        int lineNum;
        String[] vertexArray = new String[3];
        String line;
        try 
        {
            fileStrm = new FileInputStream(file);
            rdr = new InputStreamReader(fileStrm); 
            bufRdr = new BufferedReader(rdr); 
        
            lineNum = 0;
            line = bufRdr.readLine();
            while (line != null)
            {
                
                vertexArray = processLine(line, vertexArray);
                person = new Person(vertexArray[0], Integer.parseInt(vertexArray[1]), Integer.parseInt(vertexArray[2]));
                graph.addVertex(vertexArray[0], person);
                lineNum++;
                line = bufRdr.readLine();
            }
            fileStrm.close();
        }
        catch (IOException e)
        {
            if(fileStrm != null)
            {
                try
                {
                    fileStrm.close();
                }
                catch (IOException ex2) {}
            }
            System.out.println("Error in file processing: " + e.getMessage());
        }
        return graph;
    } 

    public static String[] processLine(String line, String[] array)
    {
        array = line.split(",");
        return array;
    }

    public static DSAGraph readEdges(String file, DSAGraph graph)
    {
        FileInputStream fileStrm = null;
        InputStreamReader rdr;
        BufferedReader bufRdr;
        int lineNum;
        String[] edgeArray = new String[3];
        String line;
        try 
        {
            fileStrm = new FileInputStream(file);
            rdr = new InputStreamReader(fileStrm); 
            bufRdr = new BufferedReader(rdr); 
        
            lineNum = 0;
            line = bufRdr.readLine();
            while (line != null)
            {
                edgeArray = processLine(line, edgeArray);
                graph.addEdge(edgeArray[0], edgeArray[1], edgeArray[2].charAt(0));
                lineNum++;
                line = bufRdr.readLine();
            }
            fileStrm.close();
        }
        catch (IOException e)
        {
            if(fileStrm != null)
            {
                try
                {
                    fileStrm.close();
                }
                catch (IOException ex2) {}
            }
            System.out.println("Error in file processing: " + e.getMessage());
        }
        return graph;
    } 

   
}



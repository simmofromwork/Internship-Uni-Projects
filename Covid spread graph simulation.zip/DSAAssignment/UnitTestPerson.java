import java.time.*;
public class UnitTestPerson
{
    public static void main(String[]args)
    {
        Person person = new Person("Leila", 21,0);
        int numPass=0;
        int numTest = 3;
        LocalDate date = LocalDate.now();
        //Testing constructors
        try
        {
            System.out.println("Testing constructor");
            Person person1 = new Person("Simon",21,0);
            numPass++;
            System.out.println("Passed");
        }catch(Exception e){System.out.println("Testing constructor failed " + e.getMessage());}
        //Testing setters
        try
        {
            
            System.out.println("Testing setDates");
            person.setDateInf(date);
            date = date.plusWeeks(2);
            person.setDateRem(date);
            person.setHStatus("Susceptible");
            numPass++;
            System.out.println("Passed");
        }catch(Exception e){System.out.println("Testing constructor failed " + e.getMessage());}
        


        //Testing getters
        try
        {
            System.out.println("Testing getters. Should be Leila 21 0 current date current date + 2 weeks and Susceptible");
            System.out.println(person.getName()+" " + person.getAge() +" "+ person.getState()+" "+ person.getDateInf() +" "+ person.getDateRem() +" "+ person.getHStatus());
            numPass++;
            System.out.println("Passed");
        }catch(Exception e){System.out.println("Testing constructor failed " + e.getMessage());}
        
         System.out.println( "Passed: " + numPass+"/"+numTest);
        //ToString is used when displaying the indivdual persons information in interactive mode.

    }
}
